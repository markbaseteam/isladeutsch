Link: [[Muslim Brotherhood in Germany - MOC]]
#MuslimBrotherhood #Germany #organizations

---

Founded in 1958 in [[Munich]] as the [[Islamic Community of Southern Germany]].
It changed its named to IGD in 1982.^[[[@meiningIslamicCommunityGermany2013]], 223]
Relocated in [[Cologne]] in the 2000s, then in [[Berlin]]. Its headquarter is owned by [[Europe Trust]].^[[[@vidinoMuslimBrotherhoodPanEuropean2021]], 148]

Founding member of the [[Zentralrat der Muslime in Deutschland (ZMD)(Central Council of Muslims in Germany)]] and founding member of [[Council of European Muslims (former Federation of Islamic Organizations in Europe - FIOE)]].^[[[@meiningIslamicCommunityGermany2013]], 210] ^[[@meiningIslamicCommunityGermany2013], 210]
Its membership in the ZDM, however, has been suspended in 2019 due the [[Verfassungsschutzberichte]] linking it to the MB.^[http://zentralrat.de/31822.php]


It is considered the most important MB organization in Germany,^[[[@bundesministeriumdesinnernfurbauundheimatVerfassungsschutzbericht20202021]], 220] and especially of the [[Egyptian Muslim Brotherhood]].^[[[@steinbergGermanyMuslimBrotherhood2015]]; [[@meiningIslamicCommunityGermany2013]], 211]. It cooperates with around 50 Islamic centres.^[[[@breuerMuslimbruderschaftDeutschland2019]]] and counts around 1300 members.^[[[@steinbergGermanyMuslimBrotherhood2015]]]

Among the most important organizations controlled by DMG:
- [[Islamisches Zentrum Köln (IZK)]]
- [[Muslim Studenten Vereinigung in Deutschland (MSV)]]^[[[@steinbergGermanyMuslimBrotherhood2015]]]

## Relevant personalities

Current chairman (as to 2021): [[Khallad Swaid]]

Handled by [[Said Ramadan]] between 1958 and 1968 and by [[Muhammad Mahdi Akif]] from 1984 to 1987. The latter became the [[Muslim Brotherhood]] Supreme Guide from 2004 to 2019, and advocated [[anti-Semitism]] and pro-[[Sharia]] ideas.^[[[@breuerMuslimbruderschaftDeutschland2019]]]

[[Yusuf Nada]] joined it in 1971.^[[[@meiningIslamicCommunityGermany2013]], 223]

[[Kurshid Ahmad]], founder of the [[Islamic Foundation in Leicester]], joined in 1983.^[[[@meiningIslamicCommunityGermany2013]], 223]

One of its presidents, [[Ghaleb Himmat]], stepped down in 2001 for being designated as a financier of [[terrorism]] by the US Treasury.^[[[@rubin_germany_2010]], 460]
Its successor was [[Ibrahim El-Zayat]], now former president.^[[[@meiningIslamicCommunityGermany2013]], 210], 
In 2009, Zayat was replaced by [[Samir Falah]], who in turn passed the helm to [[Khallad Swaid]] in 2017.^[[[@vidinoMuslimBrotherhoodPanEuropean2021]], 147]

Since 2018, former IGD chairman [[Samir Falah]] has been president of [[Council of European Muslims (former Federation of Islamic Organizations in Europe - FIOE)]].^[[[@vidinoMuslimBrotherhoodPanEuropean2021]], 147]

## Assessment

- The administrative Court of Ansbach has stated that it is "an organization directed against the free and democratic order, because it represents the ideology of the Sunni-extremist Muslim Brotherhood (MB) whose aim is the establishment of an Islamic divine nation".^[[[@meiningIslamicCommunityGermany2013]], 213]
- According to the 1998 Bavarian [[Verfassungsschutzberichte]] report, it has collected money for [[jihad]].
- N.B.: before the federal and regional [[Verfassungsschutzberichte]] used to describe the IGD as the "official representative" of the Muslim Brotherhood, now they more mildly point to the ideological links or to the high proportion of supporters.^[[[@meiningIslamicCommunityGermany2013]], 214]