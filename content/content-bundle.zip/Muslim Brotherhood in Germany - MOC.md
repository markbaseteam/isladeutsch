


Links: [[Muslim Brotherhood - MOC]]; [[Islamism in Germany - MOC]]


# Organizations

Umbrella:  [[Zentralrat der Muslime in Deutschland (ZMD)(Central Council of Muslims in Germany)]]

- [[Deutsche Muslimische Gemeinschaft (DMG) - former Islamische Gemeinschaft Deutschland (IGD)]]
- [[Islamische Zentrum München (IZM)]]
- [[Muslim Studenten Vereinigung in Deutschland (MSV)]]
- [[Muslimische Jugend Deutschland]]
- [[Islamische Föderation Berlin]]
- [[Neuköllner Begegnungsstätte (NBS) - Dar as-Salam Moschee (Berlin)]]
- [[Inssan e. V.]]
- [[Islamisches Zentrum Aachen (IZA) - Bilal Mosque]]
- [[Islamische Gemeinde Nürnberg (IGN)]]
- [[Fatwa-Ausschuss Deutschland (FAD)]]
- [[Allianz gegen Islam- und Muslim feindlichkeit (CLAIM) (Alliance Against Islamophobia and Anti-Muslim hate)]]
- [[Furkan Gemeinschaft]]
- [[Islamischen Konzils in Deutschland (IK)]]
- [[Haus des Islam (HDI)]]
- [[Rat der Imame und Gelehrten in Deutschland (RIGD) (Council of imams and scholars in Germany)]]
- [[European Muslim Union]]

## Disbanded

- [[Sächsische Begegnungsstätte (SBS) (Saxon Meeting Place)]]
- [[Hessian German-Islamic Association (DIV)]]

# [[Millî Görüş]]

- [[Europäische Moscheebau und Unterstützungs Gemeinschaft (EMUG)]]
- [[Islamische Gemeinschaft Millî Görüş (IGMG)]]
- [[Islamrat für die Bundesrepublik Deutschland (Islamic Council for the Federal Republic of Germany)]]
- [[Weimar Institut für geistes-und zeitgeschichtliche Fragen]]


# Iran - MB

- [[Islamische Zentrum Hamburg (IZH) + Imam Ali Mosque]]


# Global

- [[Islamic Relief Germany]]
- [[Europäisches Institut für Humanwissenschaften (EIHW)]]

# Individuals

- [[Ibrahim El-Zayat]]
- [[Aiman Mazyek]]
- [[Khaled Hanafy]]
- [[Samir Falah]]
- [[Mitwalli Mousa]]
- [[Lydia Nofal]]
- [[Mohammad Hajjaj]]
- [[Ghaleb Himmat]]
- [[Khallad Swaid]]
- [[Mohamed Taha Sabri]]
- [[Houaida Taraji]]
- [[Almoutaz Tayara]]
- [[Ahmad von Denffer]]
- [[Andreas Abu Bakr Rieger]]


# Mosques

- [[Teiba Mosque (Berlin)]]
- [[Abu Bakr Mosque (Cologne)]]
- [[Neuköllner Begegnungsstätte (NBS) - Dar as-Salam Moschee (Berlin)]]

# MB Media

[[Al-Islam (German magazine)]]

# State support

[[Demokratie Leben!]]


# Literature

- [[@meiningIslamicCommunityGermany2013]]
- [[@schroter_politischer_2019]]

# Permanent

- [[There is currently a high level of connections between Diyanet and Milli Gorus]]
- [[There are proven links between Iran and the MB]]
